#!/bin/sh

gnome-terminal -e "java -cp out/Ebay:. AuctionClient.Seller"
